import React from 'react'

const PropertyCard = () => {
  return (
    <div>PropertyCard</div>
  )
}

export default PropertyCard