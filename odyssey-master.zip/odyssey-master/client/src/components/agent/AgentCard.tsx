import React from 'react'

const AgentCard = () => {
  return (
    <div>AgentCard</div>
  )
}

export default AgentCard