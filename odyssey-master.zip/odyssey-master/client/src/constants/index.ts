export const propertyReferralsInfo = [
    {
        title: 'Mobiles',
        percentage: 13,
        color: '#6C5DD3',
    },
    {
        title: 'Furnitures',
        percentage: 16,
        color: '#7FBA7A',
    },
    {
        title: 'Clothes',
        percentage: 78,
        color: '#FFCE73',
    },
    {
        title: 'Electronics',
        percentage: 26,
        color: '#FFA2C0',
    },
    {
        title: 'Books',
        percentage: 53,
        color: '#F45252',
    },
];