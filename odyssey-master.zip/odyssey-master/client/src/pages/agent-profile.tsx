import React from 'react'

const agentProfile = () => {
  return (
    <div>agent-profile</div>
  )
}

export default agentProfile