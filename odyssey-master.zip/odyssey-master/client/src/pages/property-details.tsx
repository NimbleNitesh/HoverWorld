import React from 'react'

const propertyDetails = () => {
  return (
    <div>propertyDetails</div>
  )
}

export default propertyDetails