import React from 'react'

const agent = () => {
  return (
    <div>agent</div>
  )
}

export default agent