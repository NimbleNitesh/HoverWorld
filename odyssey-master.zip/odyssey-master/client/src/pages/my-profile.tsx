import React from 'react'

const myProfile = () => {
  return (
    <div>myProfile</div>
  )
}

export default myProfile