import React from 'react'

const editProperty = () => {
  return (
    <div>editProperty</div>
  )
}

export default editProperty